package com.jsp.WeatherReportMngtSystem.CONTROLLER;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.WeatherReportMngtSystem.DAO.WeatherDao;
import com.jsp.WeatherReportMngtSystem.DTO.Weather;

@RestController 
public class weatherController {

	@Autowired
	WeatherDao dao;
	
	// REST API TO INSERT WEATHER OBJECT INTO DB
	
	@PostMapping("/weather") // end points
	public Weather addWeather(@RequestBody Weather weather)
	{
		return dao.insertWeather(weather);
	}
	
	// REST API to get all weather details
	
	@GetMapping("/weather")
	public List<Weather> getAllReports()
	{
		return dao.getAllWeatherReports();
	}
	
	// REST API to search and get one weather report based on ID
	
	@GetMapping("/byid")
	public Weather getWeatherById(@RequestParam long weatherid)
	{
		return dao.getWeatherById(weatherid);
	}
	
	// REST API to delete a weather report from DB
	
	@DeleteMapping("/weather")
	public String deleteWeatherById(@RequestParam long id)
	{
		return dao.deleteWeatherReportById(id);
	}
	
	// REST API to update conditions and temperature based on ID
	
	@PutMapping("/weather")
	public String updateWeatherReport(@RequestParam long id , @RequestParam String conditions , @RequestParam String temperature)
	{
		return dao.updateWeatherReport(id, conditions, temperature);
	}
	
	// REST API to get all weather reports based on city
	
	@GetMapping("/city")
	public List<Weather> getAllReportsByCity(@RequestParam String city)
	{
		return dao.getAllReportsByCity(city);
	}
	
	// REST API to get all weather reports with conditions as sunny
	
	@GetMapping("/sunny")
	public List<Weather> getAllSunnyReports()
	{
		return dao.getAllSunnyReports();
	}
 }




















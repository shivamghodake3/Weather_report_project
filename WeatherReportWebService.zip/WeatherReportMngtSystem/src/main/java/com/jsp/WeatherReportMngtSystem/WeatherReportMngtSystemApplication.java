package com.jsp.WeatherReportMngtSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherReportMngtSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherReportMngtSystemApplication.class, args);
	}

}

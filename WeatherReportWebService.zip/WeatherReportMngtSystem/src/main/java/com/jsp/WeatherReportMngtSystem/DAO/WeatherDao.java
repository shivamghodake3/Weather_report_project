package com.jsp.WeatherReportMngtSystem.DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.WeatherReportMngtSystem.DTO.Weather;
import com.jsp.WeatherReportMngtSystem.REPOSITORY.WeatherRepository;

@Repository
public class WeatherDao {

	@Autowired
	WeatherRepository repository;
	
	// to insert weather record(object) into DB
	public Weather insertWeather(Weather weather)
	{
		return repository.save(weather);
	}
	
	// to retrieve all weather reports from DB
	public List<Weather> getAllWeatherReports()
	{
		return repository.findAll();
	}
	
	// to retrieve a weather report based on id
	public Weather getWeatherById(long id)
	{
		Optional<Weather> opt  = repository.findById(id);
		
		if(opt.isPresent())
		{
			return opt.get();
		}
		else
			return null;
	}
	
	// to delete a weather report from DB
	public String deleteWeatherReportById(long id)
	{
		Weather w = getWeatherById(id);
		if(w != null)
		{
			repository.delete(w);
					// OR 
			// repository.deleteById(id);
			return "Weather report deleted successfully...";
		}
		else
			return "Could not delete the requested weather report. ID not found...";
	}	
	
	// to update weather details - conditions  and temperature based on ID
	public String updateWeatherReport(long id , String newCondition , String newTemperature)
	{
		Weather w = getWeatherById(id);
	
		if(w != null)
		{
			w.setConditions(newCondition);
			w.setTemperature(newTemperature);
			repository.save(w);
			return "Weather details updated successfully...";
		}
		else
			return "Cannot update weather details. ID not found...";
	}
	
	// to retrieve all weather reports based on city
	public List<Weather> getAllReportsByCity(String city)
	{
		return repository.getAllWeatherByCity(city);
	}
	
	// to retrieve all reports having conditions as sunny
	public List<Weather> getAllSunnyReports()
	{
		return repository.getSunnyWeatherReport();
	}
}









